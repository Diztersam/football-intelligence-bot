#!/usr/bin/env python3
"""Private Telegram dashboard for the Football Intelligence Bot. Manual execution only."""
import asyncio
import html
import logging
import os
import sqlite3
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CallbackQueryHandler, CommandHandler, ContextTypes
)

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "football.db"
REPORT_PATH = BASE_DIR / "latest_report.txt"
ENV_PATH = BASE_DIR / ".env"
LAGOS = ZoneInfo("Africa/Lagos")
MAX_MESSAGE = 3900

def load_env():
    if ENV_PATH.exists():
        for raw in ENV_PATH.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))

load_env()
TOKEN = os.getenv("BOT_TOKEN", "").strip()
try:
    ALLOWED_ID = int(os.getenv("TELEGRAM_ALLOWED_USER_ID", "0"))
except ValueError:
    ALLOWED_ID = 0
if not TOKEN:
    raise RuntimeError("BOT_TOKEN is missing from .env")
if not ALLOWED_ID:
    raise RuntimeError("TELEGRAM_ALLOWED_USER_ID is missing from .env")

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger("football_bot")
RUN_LOCK = asyncio.Lock()

def allowed(update):
    return bool(update.effective_user and update.effective_user.id == ALLOWED_ID)

def dashboard():
    keyboard = [
        [InlineKeyboardButton("🚀 RUN ANALYSIS", callback_data="run"),
         InlineKeyboardButton("📊 LATEST REPORT", callback_data="latest")],
        [InlineKeyboardButton("⚽ SELECTED FIXTURES", callback_data="fixtures"),
         InlineKeyboardButton("🧠 PREDICTIONS", callback_data="predictions")],
        [InlineKeyboardButton("🗂 TEAM NEWS", callback_data="news"),
         InlineKeyboardButton("🖥 SYSTEM STATUS", callback_data="status")],
        [InlineKeyboardButton("ℹ️ HELP", callback_data="help")],
    ]
    return InlineKeyboardMarkup(keyboard)

def status_text():
    counts = {}
    if DB_PATH.exists():
        with sqlite3.connect(DB_PATH) as conn:
            for table in ("fixtures", "match_results", "team_news", "prediction_runs"):
                try:
                    counts[table] = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                except sqlite3.Error:
                    counts[table] = 0
    return (
        "🖥 <b>SYSTEM STATUS</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        f"Fixtures in active batch: <b>{counts.get('fixtures',0)}</b>/5\n"
        f"Historical results stored: <b>{counts.get('match_results',0)}</b>\n"
        f"News records: <b>{counts.get('team_news',0)}</b>\n"
        f"Prediction records: <b>{counts.get('prediction_runs',0)}</b>\n"
        f"Local time: <b>{datetime.now(LAGOS).strftime('%d %b %Y, %I:%M %p WAT')}</b>\n\n"
        "Execution mode: <b>Manual only</b>"
    )

def selected_fixtures_text():
    if not DB_PATH.exists():
        return "Database has not been created yet."
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute("SELECT * FROM fixtures ORDER BY kickoff_utc LIMIT 5").fetchall()
        except sqlite3.Error:
            rows = []
    if not rows:
        return "⚽ <b>SELECTED FIXTURES</b>\n\nNo active fixtures. Press RUN ANALYSIS."
    lines = ["⚽ <b>SELECTED FIXTURES</b>", "━━━━━━━━━━━━━━━━━━"]
    for i, r in enumerate(rows, 1):
        lines.append(
            f"\n<b>{i}. {html.escape(str(r['home_team']))} vs {html.escape(str(r['away_team']))}</b>\n"
            f"{html.escape(str(r['league']))}\n"
            f"🕒 {html.escape(str(r['kickoff_lagos']))}"
        )
    return "\n".join(lines)

def report_section(title):
    if not REPORT_PATH.exists():
        return "No report exists yet. Press RUN ANALYSIS first."
    text = REPORT_PATH.read_text(encoding="utf-8", errors="replace")
    if title == "predictions":
        markers = ["PREDICTION ENGINE", "Prediction Shortlist", "PREDICTION SHORTLIST"]
        for marker in markers:
            pos = text.lower().find(marker.lower())
            if pos >= 0:
                return text[pos:pos+11000]
    if title == "news":
        marker = "TEAM NEWS"
        pos = text.lower().find(marker.lower())
        if pos >= 0:
            return text[pos:pos+8000]
    return text

async def send_chunks(message, text):
    for start in range(0, len(text), MAX_MESSAGE):
        await message.reply_text(text[start:start+MAX_MESSAGE], parse_mode=None)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update):
        await update.effective_message.reply_text("Access denied. This is a private bot.")
        return
    await update.effective_message.reply_text(
        "⚽ FOOTBALL INTELLIGENCE\n━━━━━━━━━━━━━━━━━━\n"
        "Your personal football analysis centre is ready.\n\n"
        "Select an option below. Analysis runs only when you request it.",
        reply_markup=dashboard()
    )

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update):
        return
    await update.effective_message.reply_text(
        "/start — Open dashboard\n/run — Run full analysis\n/latest — Latest report\n/status — System status\n/myid — Show your Telegram ID\n\n"
        "The system analyses a maximum of five fixtures per run. No automatic betting or scheduled reports."
    )

async def myid(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.effective_message.reply_text(f"Your Telegram ID: {update.effective_user.id}")

async def run_analysis(message, context):
    if RUN_LOCK.locked():
        await message.reply_text("⏳ An analysis is already running. Please wait.")
        return
    async with RUN_LOCK:
        progress = await message.reply_text("🚀 <b>Analysis started</b>\nPreparing the five-fixture shortlist…", parse_mode="HTML")
        loop = asyncio.get_running_loop()
        def callback(text):
            future = asyncio.run_coroutine_threadsafe(
                progress.edit_text(text[:3900]), loop
            )
            try:
                future.result(timeout=15)
            except Exception:
                pass
        try:
            from daily_report import run_pipeline
            report = await asyncio.to_thread(run_pipeline, callback)
            await progress.edit_text("✅ <b>Analysis completed.</b>\nYour report is ready.", parse_mode="HTML")
            await send_chunks(message, report)
            await message.reply_text("Return to your dashboard:", reply_markup=dashboard())
        except Exception as exc:
            log.exception("Analysis failed")
            await progress.edit_text(f"❌ Analysis failed:\n{str(exc)[:2500]}")

async def run_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update):
        await update.effective_message.reply_text("Access denied.")
        return
    await run_analysis(update.effective_message, context)

async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not allowed(update):
        await query.answer("Access denied.", show_alert=True)
        return
    await query.answer()
    action = query.data
    if action == "run":
        await run_analysis(query.message, context)
    elif action == "latest":
        await send_chunks(query.message, report_section("latest"))
    elif action == "predictions":
        await send_chunks(query.message, report_section("predictions"))
    elif action == "news":
        await send_chunks(query.message, report_section("news"))
    elif action == "fixtures":
        await query.message.reply_text(selected_fixtures_text(), parse_mode="HTML", reply_markup=dashboard())
    elif action == "status":
        await query.message.reply_text(status_text(), parse_mode="HTML", reply_markup=dashboard())
    elif action == "help":
        await query.message.reply_text(
            "Use RUN ANALYSIS to collect a maximum of five fixtures, analyse the ten teams, "
            "collect available team news and generate evidence-based predictions.\n"
            "Reports are manual only. No automatic bet placement.",
            reply_markup=dashboard()
        )

async def latest_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update):
        return
    await send_chunks(update.effective_message, report_section("latest"))

async def status_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update):
        return
    await update.effective_message.reply_text(status_text(), parse_mode="HTML", reply_markup=dashboard())

async def error_handler(update, context):
    log.exception("Telegram update error", exc_info=context.error)

def main():
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("myid", myid))
    app.add_handler(CommandHandler("status", status_cmd))
    app.add_handler(CommandHandler("run", run_command))
    app.add_handler(CommandHandler("latest", latest_cmd))
    app.add_handler(CallbackQueryHandler(callback_handler))
    app.add_error_handler(error_handler)
    print("Football Intelligence Bot is running. Manual execution only.")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
