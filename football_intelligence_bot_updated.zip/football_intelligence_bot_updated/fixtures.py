#!/usr/bin/env python3
"""Collect and shortlist at most five upcoming fixtures from API-Football."""
import argparse
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

from api_client import get, response_items, APIFootballError

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "football.db"
LAGOS = ZoneInfo("Africa/Lagos")
MAX_FIXTURES = 5

def ensure_schema():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS fixtures (
                event_id TEXT PRIMARY KEY,
                league TEXT NOT NULL,
                home_team TEXT NOT NULL,
                away_team TEXT NOT NULL,
                kickoff_utc TEXT NOT NULL,
                kickoff_lagos TEXT NOT NULL,
                match_status TEXT,
                source_url TEXT NOT NULL,
                collected_at TEXT NOT NULL
            )
        """)
        existing = {r[1] for r in conn.execute("PRAGMA table_info(fixtures)")}
        for name, definition in [
            ("home_team_id", "INTEGER"),
            ("away_team_id", "INTEGER"),
            ("league_id", "INTEGER"),
            ("season", "INTEGER"),
            ("round_name", "TEXT"),
            ("venue", "TEXT"),
            ("home_logo", "TEXT"),
            ("away_logo", "TEXT"),
            ("league_logo", "TEXT"),
        ]:
            if name not in existing:
                conn.execute(f"ALTER TABLE fixtures ADD COLUMN {name} {definition}")
        conn.commit()

def parse_dt(value):
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except ValueError:
        return None

def collect(days=7, limit=5, force=False):
    ensure_schema()
    limit = max(1, min(int(limit), MAX_FIXTURES))
    now = datetime.now(timezone.utc)
    end = now + timedelta(days=max(1, min(int(days), 30)))
    payload = get(
        "fixtures",
        {
            "from": now.strftime("%Y-%m-%d"),
            "to": end.strftime("%Y-%m-%d"),
            "timezone": "Africa/Lagos",
        },
        ttl=900,
        force=force
    )
    candidates = []
    for item in response_items(payload):
        fx = item.get("fixture", {})
        teams = item.get("teams", {})
        league = item.get("league", {})
        home = teams.get("home") or {}
        away = teams.get("away") or {}
        kickoff = parse_dt(fx.get("date"))
        status = (fx.get("status") or {}).get("short", "")
        if not kickoff or kickoff < now or kickoff > end:
            continue
        if status not in ("NS", "TBD", "PST"):
            continue
        if not home.get("id") or not away.get("id") or not home.get("name") or not away.get("name"):
            continue
        candidates.append({
            "event_id": str(fx.get("id")),
            "league": league.get("name") or "Unknown competition",
            "home_team": home["name"],
            "away_team": away["name"],
            "kickoff_utc": kickoff.isoformat(),
            "kickoff_lagos": kickoff.astimezone(LAGOS).strftime("%Y-%m-%d %I:%M %p WAT"),
            "match_status": status,
            "source_url": "https://www.api-football.com/",
            "collected_at": datetime.now(timezone.utc).isoformat(),
            "home_team_id": home["id"],
            "away_team_id": away["id"],
            "league_id": league.get("id"),
            "season": league.get("season"),
            "round_name": league.get("round"),
            "venue": (fx.get("venue") or {}).get("name"),
            "home_logo": home.get("logo"),
            "away_logo": away.get("logo"),
            "league_logo": league.get("logo"),
        })
    candidates.sort(key=lambda x: x["kickoff_utc"])
    selected = candidates[:limit]

    with sqlite3.connect(DB_PATH) as conn:
        # fixtures is the active five-match analysis batch, not a history archive.
        conn.execute("DELETE FROM fixtures")
        for f in selected:
            conn.execute("""
                INSERT OR REPLACE INTO fixtures (
                    event_id,league,home_team,away_team,kickoff_utc,kickoff_lagos,
                    match_status,source_url,collected_at,home_team_id,away_team_id,
                    league_id,season,round_name,venue,home_logo,away_logo,league_logo
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, tuple(f[k] for k in [
                "event_id","league","home_team","away_team","kickoff_utc","kickoff_lagos",
                "match_status","source_url","collected_at","home_team_id","away_team_id",
                "league_id","season","round_name","venue","home_logo","away_logo","league_logo"
            ]))
        conn.commit()

    print("=" * 58)
    print("API-FOOTBALL | FIXTURE SHORTLIST")
    print("=" * 58)
    print(f"Discovery window: {days} days")
    print(f"Upcoming fixtures found: {len(candidates)}")
    print(f"Selected for analysis: {len(selected)} (maximum {MAX_FIXTURES})")
    if not selected:
        print("No upcoming fixtures were returned for this date window.")
    for i, f in enumerate(selected, 1):
        print(f"\n{i}. {f['home_team']} vs {f['away_team']}")
        print(f"   {f['league']} | {f['kickoff_lagos']}")
        print(f"   Fixture ID: {f['event_id']}")
    print("\nOnly these selected fixtures will be passed to downstream modules.")
    return selected

def main():
    parser = argparse.ArgumentParser(description="API-Football five-fixture collector")
    parser.add_argument("--days", type=int, default=7, help="Upcoming date window (1-30 days)")
    parser.add_argument("--limit", type=int, default=5, help="Maximum fixtures to select (hard cap: 5)")
    parser.add_argument("--force", action="store_true", help="Ignore cached fixture response")
    args = parser.parse_args()
    try:
        collect(args.days, args.limit, args.force)
    except APIFootballError as exc:
        raise SystemExit(f"FIXTURE COLLECTION FAILED: {exc}")

if __name__ == "__main__":
    main()
