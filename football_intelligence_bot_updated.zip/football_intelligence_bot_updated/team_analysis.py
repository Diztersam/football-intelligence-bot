#!/usr/bin/env python3
"""Collect recent results for only the ten teams in the active five-fixture batch."""
import argparse
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from api_client import get, response_items, APIFootballError

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "football.db"
SOURCE = "API-Football"

def connect_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def ensure_schema():
    with connect_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS match_results (
                event_id TEXT PRIMARY KEY,
                league TEXT,
                league_shortcut TEXT,
                season INTEGER,
                home_team TEXT,
                away_team TEXT,
                home_goals INTEGER,
                away_goals INTEGER,
                kickoff_utc TEXT,
                source TEXT,
                source_url TEXT,
                collected_at TEXT
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_results_home ON match_results(home_team,kickoff_utc)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_results_away ON match_results(away_team,kickoff_utc)")
        conn.commit()

def selected_fixtures():
    with connect_db() as conn:
        return [dict(r) for r in conn.execute("SELECT * FROM fixtures ORDER BY kickoff_utc LIMIT 5")]

def store_team_history(team_id, team_name, limit=10, force=False):
    payload = get(
        "fixtures",
        {"team": team_id, "last": limit, "timezone": "Africa/Lagos"},
        ttl=12 * 3600,
        force=force
    )
    saved = 0
    with connect_db() as conn:
        for item in response_items(payload):
            fx = item.get("fixture", {})
            status = (fx.get("status") or {}).get("short", "")
            goals = item.get("goals") or {}
            teams = item.get("teams") or {}
            home = teams.get("home") or {}
            away = teams.get("away") or {}
            hg, ag = goals.get("home"), goals.get("away")
            if status not in ("FT", "AET", "PEN") or hg is None or ag is None:
                continue
            event_id = str(fx.get("id"))
            league = item.get("league") or {}
            conn.execute("""
                INSERT OR REPLACE INTO match_results (
                    event_id,league,league_shortcut,season,home_team,away_team,
                    home_goals,away_goals,kickoff_utc,source,source_url,collected_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                event_id, league.get("name"), str(league.get("id") or ""),
                league.get("season"), home.get("name"), away.get("name"),
                int(hg), int(ag), fx.get("date"), SOURCE,
                "https://www.api-football.com/",
                datetime.now(timezone.utc).isoformat()
            ))
            saved += 1
        conn.commit()
    return saved

def team_matches(team_name, limit=10):
    with connect_db() as conn:
        rows = conn.execute("""
            SELECT * FROM match_results
            WHERE lower(home_team)=lower(?) OR lower(away_team)=lower(?)
            ORDER BY kickoff_utc DESC LIMIT ?
        """, (team_name, team_name, limit)).fetchall()
    return [dict(r) for r in rows]

def print_team_report(team_name):
    matches = team_matches(team_name, 10)
    if not matches:
        print(f"\n{team_name}: No completed historical matches are available in the local database.")
        return
    played = wins = draws = losses = gf = ga = 0
    for m in matches:
        is_home = (m["home_team"] or "").casefold() == team_name.casefold()
        scored = m["home_goals"] if is_home else m["away_goals"]
        conceded = m["away_goals"] if is_home else m["home_goals"]
        played += 1
        gf += scored
        ga += conceded
        if scored > conceded: wins += 1
        elif scored == conceded: draws += 1
        else: losses += 1
    print(f"\n{team_name}")
    print(f"Last {played}: W {wins} | D {draws} | L {losses}")
    print(f"Goals scored: {gf} ({gf/played:.2f}/match) | conceded: {ga} ({ga/played:.2f}/match)")
    for m in matches[:5]:
        print(f"  {m['kickoff_utc'][:10]} | {m['home_team']} {m['home_goals']}-{m['away_goals']} {m['away_team']}")

def collect_historical_results(force=False, limit=10):
    ensure_schema()
    fixtures = selected_fixtures()
    if not fixtures:
        raise RuntimeError("No active fixture batch. Run fixtures.py first.")
    teams = {}
    for f in fixtures:
        if f.get("home_team_id"):
            teams[int(f["home_team_id"])] = f["home_team"]
        if f.get("away_team_id"):
            teams[int(f["away_team_id"])] = f["away_team"]
    if not teams:
        raise RuntimeError("Selected fixtures do not contain API team IDs. Re-run fixtures.py.")
    print("=" * 58)
    print("TARGETED TEAM HISTORY COLLECTION")
    print(f"Selected fixtures: {len(fixtures)} | Unique teams: {len(teams)}")
    total = 0
    for team_id, team_name in teams.items():
        count = store_team_history(team_id, team_name, limit=limit, force=force)
        total += count
        print(f"{team_name}: {count} completed results retrieved/cached")
    print(f"\nHistorical result rows processed: {total}")
    print("Only teams belonging to the selected fixture batch were queried.")
    for team_name in teams.values():
        print_team_report(team_name)
    return total

def main():
    parser = argparse.ArgumentParser(description="API-Football team analysis")
    parser.add_argument("--collect", action="store_true", help="Collect recent results for selected teams")
    parser.add_argument("--years", type=int, default=2, help="Retained for compatibility; API request uses last-match limit")
    parser.add_argument("--team", help="Print stored analysis for one team")
    parser.add_argument("--fixtures", action="store_true", help="Analyse teams in selected fixtures")
    parser.add_argument("--limit", type=int, default=10, help="Recent matches per team (maximum 20)")
    parser.add_argument("--force", action="store_true", help="Refresh cached team histories")
    args = parser.parse_args()
    try:
        if args.collect or args.fixtures or not args.team:
            collect_historical_results(force=args.force, limit=max(1, min(args.limit, 20)))
        if args.team:
            print_team_report(args.team)
    except (APIFootballError, RuntimeError) as exc:
        raise SystemExit(f"TEAM ANALYSIS FAILED: {exc}")

if __name__ == "__main__":
    main()
