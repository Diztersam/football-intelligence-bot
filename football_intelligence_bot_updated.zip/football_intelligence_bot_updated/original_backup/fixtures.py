
#!/usr/bin/env python3

"""
FOOTBALL INTELLIGENCE BOT
GLOBAL FIXTURE COLLECTOR

Primary source: OpenLigaDB
Authentication: No API key
Database: SQLite
Timezone: Africa/Lagos

Discovers competitions and retrieves available
season fixtures. Coverage depends on the source.
"""

import argparse
import logging
import sqlite3
import sys
import time

from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


# =====================================================
# CONFIGURATION
# =====================================================

BASE_URL = "https://api.openligadb.de"
DATABASE = "football.db"

LAGOS = ZoneInfo("Africa/Lagos")

REQUEST_DELAY = 1.1
REQUEST_TIMEOUT = 30

USER_AGENT = (
    "FootballIntelligenceBot/2.0 "
    "(personal football research project)"
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

logger = logging.getLogger("football_fixtures")


# =====================================================
# HTTP SESSION
# =====================================================

def create_session():

    session = requests.Session()

    retry = Retry(
        total=3,
        connect=3,
        read=3,
        backoff_factor=2,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET"],
        respect_retry_after_header=True
    )

    adapter = HTTPAdapter(max_retries=retry)

    session.mount("https://", adapter)

    session.headers.update({
        "User-Agent": USER_AGENT,
        "Accept": "application/json"
    })

    return session


SESSION = create_session()


# =====================================================
# TIME UTILITIES
# =====================================================

def utc_now():

    return datetime.now(timezone.utc)


def parse_utc(value):

    if not value:
        return None

    try:

        result = datetime.fromisoformat(
            str(value).replace("Z", "+00:00")
        )

        # Never guess the timezone of a naive timestamp.
        if result.tzinfo is None:
            return None

        return result.astimezone(timezone.utc)

    except (ValueError, TypeError):
        return None


# =====================================================
# API REQUEST
# =====================================================

def api_get(endpoint):

    url = f"{BASE_URL}/{endpoint.lstrip('/')}"

    try:

        response = SESSION.get(
            url,
            timeout=REQUEST_TIMEOUT
        )

        response.raise_for_status()

        return response.json()

    except requests.RequestException as error:

        logger.error(
            "API request failed: %s | %s",
            endpoint,
            error
        )

    except ValueError:

        logger.error(
            "Invalid JSON returned by: %s",
            endpoint
        )

    return None


# =====================================================
# DATABASE SETUP
# =====================================================

def create_database():

    connection = sqlite3.connect(DATABASE)

    connection.execute("""
        CREATE TABLE IF NOT EXISTS fixtures (

            event_id TEXT PRIMARY KEY,

            league TEXT NOT NULL,

            home_team TEXT NOT NULL,

            away_team TEXT NOT NULL,

            kickoff_utc TEXT NOT NULL,

            kickoff_lagos TEXT NOT NULL,

            match_status TEXT,

            source_url TEXT NOT NULL,

            collected_at TEXT NOT NULL
        )
    """)

    connection.execute("""
        CREATE INDEX IF NOT EXISTS
        idx_fixtures_kickoff
        ON fixtures(kickoff_utc)
    """)

    connection.execute("""
        CREATE TABLE IF NOT EXISTS collection_log (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            competition TEXT,

            season TEXT,

            source TEXT,

            status TEXT,

            fixtures_found INTEGER,

            collected_at TEXT
        )
    """)

    connection.commit()
    connection.close()


# =====================================================
# DISCOVER COMPETITIONS
# =====================================================

def discover_competitions():

    current_year = utc_now().year

    years_to_check = [
        current_year,
        current_year - 1
    ]

    discovered = {}

    for year in years_to_check:

        print(
            f"Discovering competitions for {year}..."
        )

        endpoint = f"getavailableleagues/{year}"

        leagues = api_get(endpoint)

        if leagues is None:

            logger.warning(
                "Could not discover leagues for %s",
                year
            )

            continue

        if not isinstance(leagues, list):

            logger.warning(
                "Unexpected league response for %s",
                year
            )

            continue

        for league in leagues:

            if not isinstance(league, dict):
                continue

            shortcut = league.get("leagueShortcut")
            season = league.get("leagueSeason")

            if not shortcut or season is None:
                continue

            shortcut = str(shortcut).strip()
            season = str(season).strip()

            key = (shortcut, season)

            discovered[key] = {
                "shortcut": shortcut,
                "season": season,
                "name": (
                    league.get("leagueName")
                    or shortcut
                )
            }

        time.sleep(REQUEST_DELAY)

    # Keep the newest discovered season for each
    # competition shortcut to avoid fetching duplicate
    # historical seasons.
    latest = {}

    for competition in discovered.values():

        shortcut = competition["shortcut"]

        try:
            season_number = int(competition["season"])
        except ValueError:
            continue

        existing = latest.get(shortcut)

        if existing is None:

            latest[shortcut] = competition

        else:

            try:
                existing_year = int(existing["season"])
            except ValueError:
                existing_year = 0

            if season_number > existing_year:
                latest[shortcut] = competition

    competitions = list(latest.values())

    competitions.sort(
        key=lambda item: item["name"].lower()
    )

    return competitions


# =====================================================
# RECORD COLLECTION STATUS
# =====================================================

def log_collection(
    competition,
    status,
    fixtures_found=0
):

    connection = sqlite3.connect(DATABASE)

    connection.execute("""
        INSERT INTO collection_log (

            competition,
            season,
            source,
            status,
            fixtures_found,
            collected_at

        )
        VALUES (?, ?, ?, ?, ?, ?)
    """, (

        competition["name"],
        competition["season"],
        "OpenLigaDB",
        status,
        fixtures_found,
        utc_now().isoformat()

    ))

    connection.commit()
    connection.close()


# =====================================================
# FETCH COMPETITION FIXTURES
# =====================================================

def fetch_competition(competition):

    shortcut = competition["shortcut"]
    season = competition["season"]

    endpoint = (
        f"getmatchdata/{shortcut}/{season}"
    )

    results = api_get(endpoint)

    if results is None:

        log_collection(
            competition,
            "FAILED"
        )

        return None

    if not isinstance(results, list):

        log_collection(
            competition,
            "INVALID_RESPONSE"
        )

        return None

    fixtures = []

    now = utc_now()

    for match in results:

        if not isinstance(match, dict):
            continue

        match_id = match.get("matchID")

        if match_id is None:
            continue

        kickoff = parse_utc(
            match.get("matchDateTimeUTC")
        )

        # Do not invent timezone information.
        if kickoff is None:
            continue

        if kickoff <= now:
            continue

        team1 = match.get("team1") or {}
        team2 = match.get("team2") or {}

        home = team1.get("teamName")
        away = team2.get("teamName")

        if not home or not away:
            continue

        kickoff_lagos = kickoff.astimezone(LAGOS)

        league_name = (
            match.get("leagueName")
            or competition["name"]
        )

        match_season = (
            match.get("leagueSeason")
            or competition["season"]
        )

        fixtures.append({

            "event_id": f"openligadb:{match_id}",

            "league": (
                f"{league_name} ({match_season})"
            ),

            "home_team": home,

            "away_team": away,

            "kickoff_utc": kickoff.isoformat(),

            "kickoff_lagos": (
                kickoff_lagos.strftime(
                    "%Y-%m-%d %H:%M"
                )
            ),

            "match_status": "Scheduled",

            "source_url": (
                f"{BASE_URL}/getmatchdata/{match_id}"
            )

        })

    log_collection(
        competition,
        "SUCCESS",
        len(fixtures)
    )

    return fixtures


# =====================================================
# SAVE FIXTURES
# =====================================================

def save_fixtures(fixtures):

    connection = sqlite3.connect(DATABASE)

    collected_at = utc_now().isoformat()

    for fixture in fixtures:

        connection.execute("""

            INSERT INTO fixtures (

                event_id,
                league,
                home_team,
                away_team,
                kickoff_utc,
                kickoff_lagos,
                match_status,
                source_url,
                collected_at

            )

            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)

            ON CONFLICT(event_id)
            DO UPDATE SET

                league = excluded.league,

                home_team = excluded.home_team,

                away_team = excluded.away_team,

                kickoff_utc = excluded.kickoff_utc,

                kickoff_lagos = excluded.kickoff_lagos,

                match_status = excluded.match_status,

                source_url = excluded.source_url,

                collected_at = excluded.collected_at

        """, (

            fixture["event_id"],
            fixture["league"],
            fixture["home_team"],
            fixture["away_team"],
            fixture["kickoff_utc"],
            fixture["kickoff_lagos"],
            fixture["match_status"],
            fixture["source_url"],
            collected_at

        ))

    connection.commit()
    connection.close()


# =====================================================
# READ UPCOMING FIXTURES
# =====================================================

def get_upcoming_fixtures(days=14):

    connection = sqlite3.connect(DATABASE)

    connection.row_factory = sqlite3.Row

    start = utc_now()
    end = start + timedelta(days=days)

    rows = connection.execute("""

        SELECT *
        FROM fixtures

        WHERE kickoff_utc > ?
        AND kickoff_utc <= ?

        ORDER BY kickoff_utc ASC

    """, (

        start.isoformat(),
        end.isoformat()

    )).fetchall()

    connection.close()

    return [dict(row) for row in rows]


# =====================================================
# DISPLAY COLLECTION REPORT
# =====================================================

def display_report(
    competitions,
    successful,
    failed,
    fixtures,
    days
):

    upcoming = get_upcoming_fixtures(days)

    print("\n" + "=" * 55)
    print("          FOOTBALL INTELLIGENCE")
    print("          FIXTURE COLLECTION REPORT")
    print("=" * 55)

    print(
        f"\nCompetitions discovered: {len(competitions)}"
    )

    print(
        f"Successful collections: {successful}"
    )

    print(
        f"Failed collections: {failed}"
    )

    print(
        f"New fixtures collected: {len(fixtures)}"
    )

    print(
        f"Upcoming matches in next {days} days: "
        f"{len(upcoming)}"
    )

    print("\n" + "-" * 55)
    print("UPCOMING MATCHES")
    print("-" * 55)

    if not upcoming:

        print(
            "\nNo upcoming fixtures found "
            "in the selected period."
        )

    for number, match in enumerate(
        upcoming,
        start=1
    ):

        print(
            f"\n{number}. "
            f"{match['home_team']} "
            f"vs {match['away_team']}"
        )

        print(
            f"   Competition: {match['league']}"
        )

        print(
            f"   Kick-off: "
            f"{match['kickoff_lagos']} WAT"
        )

        print(
            f"   Source: {match['source_url']}"
        )

    print("\n" + "=" * 55)

    if failed:
        print(
            "WARNING: Collection is incomplete. "
            "Some competitions failed."
        )

    print(
        "Source coverage is not equivalent "
        "to worldwide fixture coverage."
    )

    print(
        f"Database: {DATABASE}"
    )

    print("=" * 55)


# =====================================================
# MAIN
# =====================================================

def main():

    parser = argparse.ArgumentParser(
        description="Multi-competition football fixture collector"
    )

    parser.add_argument(
        "--days",
        type=int,
        default=14,
        help="Number of upcoming days to display"
    )

    parser.add_argument(
        "--limit",
        type=int,
        default=0,
        help="Limit competitions for testing; 0 means all"
    )

    args = parser.parse_args()

    if args.days < 1:
        parser.error("--days must be at least 1")

    if args.limit < 0:
        parser.error("--limit cannot be negative")

    create_database()

    print("\nStarting Football Intelligence Fixture Collector")
    print("Source: OpenLigaDB")
    print("Timezone: Africa/Lagos")
    print("Authentication: No API key required\n")

    competitions = discover_competitions()

    if not competitions:

        print(
            "\nNo competitions discovered. "
            "Check the API connection."
        )

        sys.exit(1)

    if args.limit:
        competitions = competitions[:args.limit]

    print(
        f"\nDiscovered {len(competitions)} competitions."
    )

    all_fixtures = []

    successful = 0
    failed = 0

    for index, competition in enumerate(
        competitions,
        start=1
    ):

        print(
            f"\n[{index}/{len(competitions)}] "
            f"{competition['name']} "
            f"({competition['season']})"
        )

        result = fetch_competition(
            competition
        )

        if result is None:

            failed += 1

        else:

            successful += 1

            all_fixtures.extend(result)

        # Respect the provider's request guidance.
        time.sleep(REQUEST_DELAY)

    if all_fixtures:
        save_fixtures(all_fixtures)

    display_report(
        competitions,
        successful,
        failed,
        all_fixtures,
        args.days
    )


if __name__ == "__main__":
    main()
