
#!/usr/bin/env python3

import os
import sys
import sqlite3
import asyncio
import logging
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from concurrent.futures import TimeoutError as FutureTimeout

from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
)

# ==========================================================
# CONFIGURATION
# ==========================================================

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "football.db"
REPORT_PATH = BASE_DIR / "latest_report.txt"
ENV_PATH = BASE_DIR / ".env"

LAGOS = ZoneInfo("Africa/Lagos")
MAX_MESSAGE_LENGTH = 3900

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)

logger = logging.getLogger("FootballIntelligenceBot")

RUN_LOCK = asyncio.Lock()


# ==========================================================
# ENVIRONMENT
# ==========================================================

def load_env():
    if not ENV_PATH.exists():
        raise FileNotFoundError(".env file is missing.")

    with open(ENV_PATH, "r", encoding="utf-8") as file:
        for line in file:
            line = line.strip()

            if not line or line.startswith("#") or "=" not in line:
                continue

            key, value = line.split("=", 1)
            os.environ.setdefault(
                key.strip(),
                value.strip().strip('"').strip("'"),
            )


load_env()

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
ALLOWED_USER_ID = os.getenv(
    "TELEGRAM_ALLOWED_USER_ID", ""
).strip()

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN is missing from .env")

try:
    ALLOWED_USER_ID = int(ALLOWED_USER_ID)
except (ValueError, TypeError):
    ALLOWED_USER_ID = None


# ==========================================================
# ACCESS CONTROL
# ==========================================================

def authorised(update: Update) -> bool:
    return (
        update.effective_user is not None
        and ALLOWED_USER_ID is not None
        and update.effective_user.id == ALLOWED_USER_ID
    )


async def require_authorisation(update, context):
    if not authorised(update):
        await update.effective_message.reply_text(
            "Access denied. This is a private bot."
        )
        return False

    return True


# ==========================================================
# MESSAGE UTILITIES
# ==========================================================

async def send_long_message(message, content):
    if not content:
        content = "No report content was returned."

    for start in range(0, len(content), MAX_MESSAGE_LENGTH):
        await message.reply_text(
            content[start:start + MAX_MESSAGE_LENGTH]
        )


def get_latest_report():
    if not REPORT_PATH.exists():
        return None

    return REPORT_PATH.read_text(
        encoding="utf-8"
    ).strip()


# ==========================================================
# DATABASE STATUS
# ==========================================================

def table_count(connection, table):
    try:
        return connection.execute(
            f'SELECT COUNT(*) FROM "{table}"'
        ).fetchone()[0]
    except sqlite3.Error:
        return 0


def get_system_status():
    if not DB_PATH.exists():
        return "Database not found."

    with sqlite3.connect(DB_PATH) as connection:
        fixtures = table_count(connection, "fixtures")
        results = table_count(connection, "match_results")
        news = table_count(connection, "team_news")
        predictions = table_count(connection, "prediction_runs")

    now = datetime.now(LAGOS).strftime(
        "%d %B %Y, %I:%M:%S %p"
    )

    return f"""
FOOTBALL INTELLIGENCE SYSTEM
━━━━━━━━━━━━━━━━━━━━

System time: {now}

DATABASE
Fixtures: {fixtures}
Historical results: {results}
News records: {news}
Prediction records: {predictions}

LATEST REPORT
{"Available" if REPORT_PATH.exists() else "Not generated"}

REPORT CONTROL
Generation: MANUAL
Automatic reports: DISABLED
Automatic delivery: DISABLED

BOT STATUS: ONLINE
━━━━━━━━━━━━━━━━━━━━
""".strip()


# ==========================================================
# START
# ==========================================================

async def start_command(update, context):
    await update.message.reply_text(
        "WELCOME TO FOOTBALL INTELLIGENCE\n\n"
        "You are in control of report generation.\n\n"
        "/run - Generate a fresh report\n"
        "/latest - Retrieve your last report\n"
        "/status - Check system status\n"
        "/help - View all commands\n"
        "/myid - Display your Telegram ID\n\n"
        "No automatic reports will be sent."
    )


# ==========================================================
# HELP
# ==========================================================

async def help_command(update, context):
    await update.message.reply_text(
        "FOOTBALL INTELLIGENCE COMMANDS\n\n"
        "/start - Open the bot\n"
        "/help - Show commands\n"
        "/myid - Display your Telegram ID\n"
        "/status - Check system records\n"
        "/run - Generate a fresh report\n"
        "/latest - Receive your last saved report\n\n"
        "When you use /run, the bot will show progress "
        "for each analysis module."
    )


# ==========================================================
# MY ID
# ==========================================================

async def myid_command(update, context):
    await update.message.reply_text(
        f"Your Telegram User ID: {update.effective_user.id}\n"
        f"Your Chat ID: {update.effective_chat.id}"
    )


# ==========================================================
# STATUS
# ==========================================================

async def status_command(update, context):
    if not await require_authorisation(update, context):
        return

    try:
        await update.message.reply_text(get_system_status())
    except Exception:
        logger.exception("Status command failed")
        await update.message.reply_text(
            "Unable to retrieve system status."
        )


# ==========================================================
# RUN WITH LIVE TELEGRAM PROGRESS
# ==========================================================

async def run_command(update, context):
    if not await require_authorisation(update, context):
        return

    if RUN_LOCK.locked():
        await update.message.reply_text(
            "An analysis is already running. "
            "Please wait for its report."
        )
        return

    async with RUN_LOCK:
        progress_message = await update.message.reply_text(
            "FOOTBALL INTELLIGENCE\n\n"
            "Your report request has been accepted.\n"
            "Preparing analysis..."
        )

        loop = asyncio.get_running_loop()

        def progress_callback(text):
            """Called by the worker thread to update Telegram."""

            try:
                future = asyncio.run_coroutine_threadsafe(
                    progress_message.edit_text(text),
                    loop,
                )
                future.result(timeout=20)

            except FutureTimeout:
                logger.warning("Telegram progress update timed out")

            except Exception as error:
                logger.warning(
                    "Could not update progress message: %s",
                    error,
                )

        try:
            from daily_report import run_pipeline

            report = await asyncio.to_thread(
                run_pipeline,
                progress_callback,
            )

            if not report:
                await progress_message.edit_text(
                    "The analysis finished, but no report was returned."
                )
                return

            if report.startswith("Another analysis is already running"):
                await progress_message.edit_text(report)
                return

            await progress_message.edit_text(
                "✓ ANALYSIS COMPLETED\n\n"
                "Your football intelligence report is ready.\n"
                "Sending report..."
            )

            await send_long_message(
                update.message,
                report,
            )

            logger.info(
                "Report delivered to user %s",
                update.effective_user.id,
            )

        except Exception as error:
            logger.exception("Report generation failed")

            await progress_message.edit_text(
                "REPORT GENERATION FAILED\n\n"
                f"Error: {str(error)[:1200]}\n\n"
                "Check the Kali terminal for details."
            )


# ==========================================================
# LATEST REPORT
# ==========================================================

async def latest_command(update, context):
    if not await require_authorisation(update, context):
        return

    report = get_latest_report()

    if not report:
        await update.message.reply_text(
            "No saved report found.\n\n"
            "Send /run to generate your first report."
        )
        return

    await update.message.reply_text(
        "YOUR LATEST SAVED FOOTBALL REPORT"
    )

    await send_long_message(
        update.message,
        report,
    )


# ==========================================================
# ERROR HANDLER
# ==========================================================

async def error_handler(update, context):
    logger.error(
        "Telegram update error",
        exc_info=context.error,
    )


# ==========================================================
# MAIN
# ==========================================================

def main():
    application = (
        Application.builder()
        .token(BOT_TOKEN)
        .build()
    )

    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("myid", myid_command))
    application.add_handler(CommandHandler("status", status_command))
    application.add_handler(CommandHandler("run", run_command))
    application.add_handler(CommandHandler("latest", latest_command))

    application.add_error_handler(error_handler)

    logger.info("Football Intelligence Bot starting...")

    application.run_polling(
        allowed_updates=Update.ALL_TYPES
    )


if __name__ == "__main__":
    main()
