
#!/usr/bin/env python3
"""
Team Performance Analysis
Source: OpenLigaDB public API
Database: football.db

Functions:
- Collect completed historical matches.
- Store verified full-time results in SQLite.
- Analyse last 5 and last 10 matches.
- Calculate home/away performance.
- Calculate head-to-head results where available.
- Analyse upcoming fixtures already stored by fixtures.py.

No API key required. No fabricated results.
"""

import argparse
import json
import logging
import re
import sqlite3
import time
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

BASE_URL = "https://api.openligadb.de"
DB_FILE = Path(__file__).resolve().parent / "football.db"
SOURCE = "OpenLigaDB"
REQUEST_DELAY = 1.1
TIMEOUT = 25

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

log = logging.getLogger("team_analysis")


# ---------------------------------------------------------
# DATABASE
# ---------------------------------------------------------

def connect_db():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn


def create_tables():
    with connect_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS match_results (
                event_id TEXT PRIMARY KEY,
                league TEXT,
                league_shortcut TEXT,
                season INTEGER,
                home_team TEXT,
                away_team TEXT,
                home_goals INTEGER,
                away_goals INTEGER,
                kickoff_utc TEXT,
                source TEXT,
                source_url TEXT,
                collected_at TEXT
            )
        """)

        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_results_home
            ON match_results(home_team, kickoff_utc)
        """)

        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_results_away
            ON match_results(away_team, kickoff_utc)
        """)

        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_results_date
            ON match_results(kickoff_utc)
        """)


# ---------------------------------------------------------
# HTTP / API
# ---------------------------------------------------------

def api_get(endpoint):
    url = f"{BASE_URL}{endpoint}"

    request = Request(
        url,
        headers={
            "User-Agent": "FootballIntelligenceBot/1.0",
            "Accept": "application/json"
        }
    )

    try:
        with urlopen(request, timeout=TIMEOUT) as response:
            if response.status != 200:
                log.warning("HTTP %s: %s", response.status, url)
                return None

            raw = response.read().decode("utf-8")
            return json.loads(raw)

    except HTTPError as exc:
        log.warning("HTTP error %s for %s", exc.code, url)
    except URLError as exc:
        log.warning("Connection error for %s: %s", url, exc.reason)
    except TimeoutError:
        log.warning("Request timed out: %s", url)
    except json.JSONDecodeError:
        log.warning("Invalid JSON returned by: %s", url)
    except Exception as exc:
        log.warning("Request failed: %s", exc)

    return None


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def parse_date(value):
    if not value:
        return None

    try:
        cleaned = value.replace("Z", "+00:00")
        dt = datetime.fromisoformat(cleaned)

        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)

        return dt.astimezone(timezone.utc)
    except (ValueError, TypeError):
        return None


# ---------------------------------------------------------
# COMPETITION DISCOVERY
# ---------------------------------------------------------

def discover_competitions(years_back=2):
    """
    Discover competitions listed by OpenLigaDB for recent
    season years. Coverage depends on the source.
    """

    current_year = datetime.now(timezone.utc).year
    competitions = {}

    for year in range(current_year, current_year - years_back - 1, -1):
        log.info("Discovering competitions for season year %s", year)

        data = api_get(f"/getavailableleagues/{year}")

        if not isinstance(data, list):
            log.warning("No valid league list for %s", year)
            continue

        for league in data:
            if not isinstance(league, dict):
                continue

            shortcut = league.get("leagueShortcut")
            season = league.get("leagueSeason")
            name = league.get("leagueName") or shortcut

            if not shortcut or season is None:
                continue

            key = (str(shortcut), int(season))

            competitions[key] = {
                "shortcut": str(shortcut),
                "season": int(season),
                "name": str(name)
            }

        time.sleep(REQUEST_DELAY)

    result = list(competitions.values())
    log.info("Discovered %s competition-season entries", len(result))
    return result


# ---------------------------------------------------------
# FULL-TIME SCORE EXTRACTION
# ---------------------------------------------------------

def extract_full_time_score(match):
    """
    Prefer the result explicitly identified as After90Minutes.
    Fall back to Endergebnis or resultTypeID=2.

    Do not simply select the first result: it may be half-time.
    """

    results = match.get("matchResults") or []

    if not isinstance(results, list):
        return None

    # Preferred: result type explicitly means after 90 minutes.
    for result in results:
        if not isinstance(result, dict):
            continue

        kind = str(result.get("resultTypeKind") or "").lower()

        if kind == "after90minutes":
            try:
                return (
                    int(result["pointsTeam1"]),
                    int(result["pointsTeam2"])
                )
            except (KeyError, TypeError, ValueError):
                pass

    # Common OpenLigaDB full-time label.
    for result in results:
        if not isinstance(result, dict):
            continue

        name = str(result.get("resultName") or "").strip().lower()

        if name in ("endergebnis", "final result"):
            try:
                return (
                    int(result["pointsTeam1"]),
                    int(result["pointsTeam2"])
                )
            except (KeyError, TypeError, ValueError):
                pass

    # Final fallback: resultTypeID 2.
    for result in results:
        if not isinstance(result, dict):
            continue

        if str(result.get("resultTypeID")) == "2":
            try:
                return (
                    int(result["pointsTeam1"]),
                    int(result["pointsTeam2"])
                )
            except (KeyError, TypeError, ValueError):
                pass

    return None


# ---------------------------------------------------------
# SAVE HISTORICAL RESULTS
# ---------------------------------------------------------

def save_result(match, competition):
    if not isinstance(match, dict):
        return False

    if match.get("matchIsFinished") is not True:
        return False

    home = match.get("team1") or {}
    away = match.get("team2") or {}

    home_name = home.get("teamName")
    away_name = away.get("teamName")

    if not home_name or not away_name:
        return False

    score = extract_full_time_score(match)

    if score is None:
        return False

    kickoff = (
        match.get("matchDateTimeUTC")
        or match.get("matchDateTime")
    )

    parsed = parse_date(kickoff)

    if parsed is None:
        return False

    match_id = match.get("matchID")

    if match_id is None:
        return False

    event_id = f"openligadb:{match_id}"
    shortcut = competition["shortcut"]
    season = competition["season"]
    league = match.get("leagueName") or competition["name"]

    source_url = (
        f"{BASE_URL}/getmatchdata/"
        f"{shortcut}/{season}"
    )

    with connect_db() as conn:
        conn.execute("""
            INSERT INTO match_results (
                event_id,
                league,
                league_shortcut,
                season,
                home_team,
                away_team,
                home_goals,
                away_goals,
                kickoff_utc,
                source,
                source_url,
                collected_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)

            ON CONFLICT(event_id) DO UPDATE SET
                league = excluded.league,
                home_team = excluded.home_team,
                away_team = excluded.away_team,
                home_goals = excluded.home_goals,
                away_goals = excluded.away_goals,
                kickoff_utc = excluded.kickoff_utc,
                collected_at = excluded.collected_at
        """, (
            event_id,
            league,
            shortcut,
            season,
            home_name,
            away_name,
            score[0],
            score[1],
            parsed.isoformat(),
            SOURCE,
            source_url,
            utc_now()
        ))

    return True


def collect_historical_results(years_back=2):
    create_tables()

    competitions = discover_competitions(years_back)
    total_saved = 0
    failed = 0

    for index, competition in enumerate(competitions, start=1):
        shortcut = competition["shortcut"]
        season = competition["season"]
        name = competition["name"]

        log.info(
            "[%s/%s] Collecting %s (%s)",
            index,
            len(competitions),
            name,
            season
        )

        endpoint = f"/getmatchdata/{shortcut}/{season}"
        matches = api_get(endpoint)

        if not isinstance(matches, list):
            failed += 1
            log.warning("Skipped invalid response: %s", endpoint)
            time.sleep(REQUEST_DELAY)
            continue

        saved_this_competition = 0

        for match in matches:
            if save_result(match, competition):
                saved_this_competition += 1

        total_saved += saved_this_competition

        log.info(
            "%s: saved/updated %s completed results",
            name,
            saved_this_competition
        )

        time.sleep(REQUEST_DELAY)

    log.info("Historical collection finished.")
    log.info("Results saved/updated: %s", total_saved)
    log.info("Failed competition requests: %s", failed)

    return total_saved


# ---------------------------------------------------------
# TEAM NAME NORMALISATION
# ---------------------------------------------------------

def normalise_team(name):
    if not name:
        return ""

    value = unicodedata.normalize("NFKD", str(name))
    value = "".join(
        char for char in value
        if not unicodedata.combining(char)
    )

    value = value.lower()
    value = re.sub(r"[^a-z0-9]+", " ", value)

    return " ".join(value.split())


# ---------------------------------------------------------
# TEAM MATCH HISTORY
# ---------------------------------------------------------

def get_team_matches(team_name, limit=10):
    target = normalise_team(team_name)

    with connect_db() as conn:
        rows = conn.execute("""
            SELECT *
            FROM match_results
            ORDER BY kickoff_utc DESC
        """).fetchall()

    matches = []

    for row in rows:
        home = normalise_team(row["home_team"])
        away = normalise_team(row["away_team"])

        if home == target or away == target:
            matches.append(dict(row))

    return matches[:limit]


def calculate_team_stats(team_name, limit=10):
    matches = get_team_matches(team_name, limit)

    if not matches:
        return {
            "team": team_name,
            "matches_found": 0,
            "message": "No historical results found for this team."
        }

    played = 0
    wins = 0
    draws = 0
    losses = 0
    goals_for = 0
    goals_against = 0
    clean_sheets = 0
    scored_in = 0
    home_played = 0
    home_wins = 0
    away_played = 0
    away_wins = 0
    form = []

    target = normalise_team(team_name)

    for match in matches:
        home_side = (
            normalise_team(match["home_team"]) == target
        )

        if home_side:
            scored = match["home_goals"]
            conceded = match["away_goals"]
            home_played += 1
        else:
            scored = match["away_goals"]
            conceded = match["home_goals"]
            away_played += 1

        played += 1
        goals_for += scored
        goals_against += conceded

        if scored > 0:
            scored_in += 1

        if conceded == 0:
            clean_sheets += 1

        if scored > conceded:
            wins += 1
            form.append("W")

            if home_side:
                home_wins += 1
            else:
                away_wins += 1

        elif scored == conceded:
            draws += 1
            form.append("D")

        else:
            losses += 1
            form.append("L")

    return {
        "team": team_name,
        "matches_found": played,
        "wins": wins,
        "draws": draws,
        "losses": losses,
        "form": "-".join(form),
        "goals_for": goals_for,
        "goals_against": goals_against,
        "avg_goals_for": round(goals_for / played, 2),
        "avg_goals_against": round(goals_against / played, 2),
        "clean_sheets": clean_sheets,
        "scored_in": scored_in,
        "home_played": home_played,
        "home_wins": home_wins,
        "away_played": away_played,
        "away_wins": away_wins,
        "data_warning": (
            "Fewer than 5 matches available"
            if played < 5 else None
        )
    }


# ---------------------------------------------------------
# HEAD-TO-HEAD
# ---------------------------------------------------------

def get_head_to_head(home_team, away_team, limit=10):
    home_target = normalise_team(home_team)
    away_target = normalise_team(away_team)

    with connect_db() as conn:
        rows = conn.execute("""
            SELECT *
            FROM match_results
            ORDER BY kickoff_utc DESC
        """).fetchall()

    meetings = []

    for row in rows:
        first = normalise_team(row["home_team"])
        second = normalise_team(row["away_team"])

        if (
            (first == home_target and second == away_target)
            or
            (first == away_target and second == home_target)
        ):
            meetings.append(dict(row))

    meetings = meetings[:limit]

    home_wins = 0
    draws = 0
    away_wins = 0

    for match in meetings:
        first = normalise_team(match["home_team"])
        score_home = match["home_goals"]
        score_away = match["away_goals"]

        if score_home == score_away:
            draws += 1
        elif score_home > score_away:
            if first == home_target:
                home_wins += 1
            else:
                away_wins += 1
        else:
            if first == home_target:
                away_wins += 1
            else:
                home_wins += 1

    return {
        "meetings": len(meetings),
        "home_team": home_team,
        "away_team": away_team,
        "home_team_wins": home_wins,
        "draws": draws,
        "away_team_wins": away_wins,
        "matches": meetings
    }


# ---------------------------------------------------------
# UPCOMING FIXTURES
# ---------------------------------------------------------

def get_upcoming_fixtures():
    """
    Reads the fixtures table created by fixtures.py.
    """

    with connect_db() as conn:
        try:
            rows = conn.execute("""
                SELECT *
                FROM fixtures
                WHERE kickoff_utc IS NOT NULL
                ORDER BY kickoff_utc ASC
            """).fetchall()

            return [dict(row) for row in rows]

        except sqlite3.OperationalError:
            log.error(
                "fixtures table not found. Run fixtures.py first."
            )
            return []


# ---------------------------------------------------------
# REPORT
# ---------------------------------------------------------

def print_team_report(team_name):
    stats = calculate_team_stats(team_name, 10)

    print("\n" + "=" * 58)
    print(f"TEAM PERFORMANCE: {team_name}")
    print("=" * 58)

    if stats["matches_found"] == 0:
        print(stats["message"])
        return

    print(f"Matches analysed : {stats['matches_found']}")
    print(f"Recent form      : {stats['form']}")
    print(
        f"W-D-L            : "
        f"{stats['wins']}-{stats['draws']}-{stats['losses']}"
    )
    print(f"Goals scored     : {stats['goals_for']}")
    print(f"Goals conceded   : {stats['goals_against']}")
    print(f"Average scored   : {stats['avg_goals_for']}")
    print(f"Average conceded : {stats['avg_goals_against']}")
    print(f"Clean sheets     : {stats['clean_sheets']}")
    print(f"Scored in        : {stats['scored_in']} matches")
    print(
        f"Home record      : {stats['home_wins']} wins "
        f"from {stats['home_played']} matches"
    )
    print(
        f"Away record      : {stats['away_wins']} wins "
        f"from {stats['away_played']} matches"
    )

    if stats["data_warning"]:
        print(f"DATA WARNING     : {stats['data_warning']}")

    print("\nRecent matches:")

    for match in get_team_matches(team_name, 10):
        print(
            f"{match['kickoff_utc'][:10]} | "
            f"{match['home_team']} "
            f"{match['home_goals']}-{match['away_goals']} "
            f"{match['away_team']} | {match['league']}"
        )


def analyse_upcoming_fixtures(limit=20):
    fixtures = get_upcoming_fixtures()

    print("\n" + "=" * 65)
    print("UPCOMING FIXTURE TEAM ANALYSIS")
    print("=" * 65)

    if not fixtures:
        print("No upcoming fixtures found. Run fixtures.py first.")
        return

    shown = 0

    for fixture in fixtures:
        home = fixture.get("home_team")
        away = fixture.get("away_team")

        if not home or not away:
            continue

        print("\n" + "-" * 65)
        print(
            f"{fixture.get('league', 'Unknown league')} | "
            f"{fixture.get('kickoff_lagos', fixture.get('kickoff_utc', ''))}"
        )
        print(f"{home} vs {away}")

        home_stats = calculate_team_stats(home, 10)
        away_stats = calculate_team_stats(away, 10)
        h2h = get_head_to_head(home, away)

        print(
            f"{home}: "
            f"{home_stats.get('form', 'No data')} | "
            f"{home_stats.get('matches_found', 0)} matches | "
            f"GF {home_stats.get('avg_goals_for', 'N/A')} "
            f"GA {home_stats.get('avg_goals_against', 'N/A')}"
        )

        print(
            f"{away}: "
            f"{away_stats.get('form', 'No data')} | "
            f"{away_stats.get('matches_found', 0)} matches | "
            f"GF {away_stats.get('avg_goals_for', 'N/A')} "
            f"GA {away_stats.get('avg_goals_against', 'N/A')}"
        )

        print(
            f"Head-to-head: {h2h['meetings']} meetings | "
            f"{home} wins {h2h['home_team_wins']} | "
            f"Draws {h2h['draws']} | "
            f"{away} wins {h2h['away_team_wins']}"
        )

        if (
            home_stats.get("matches_found", 0) < 5
            or away_stats.get("matches_found", 0) < 5
        ):
            print("WARNING: Insufficient recent results for one or both teams.")

        shown += 1

        if shown >= limit:
            break

    print("\nAnalysis complete.")
    print("This is statistical information, not a betting guarantee.")


# ---------------------------------------------------------
# COMMAND LINE
# ---------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Football historical results and team analysis"
    )

    parser.add_argument(
        "--collect",
        action="store_true",
        help="Collect historical results from OpenLigaDB"
    )

    parser.add_argument(
        "--years",
        type=int,
        default=2,
        help="Number of previous season years to include"
    )

    parser.add_argument(
        "--team",
        type=str,
        help="Analyse a specific team"
    )

    parser.add_argument(
        "--fixtures",
        action="store_true",
        help="Analyse upcoming fixtures"
    )

    parser.add_argument(
        "--limit",
        type=int,
        default=20,
        help="Maximum upcoming fixtures to analyse"
    )

    args = parser.parse_args()

    create_tables()

    if args.collect:
        collect_historical_results(args.years)

    if args.team:
        print_team_report(args.team)

    if args.fixtures:
        analyse_upcoming_fixtures(args.limit)

    if not args.collect and not args.team and not args.fixtures:
        parser.print_help()


if __name__ == "__main__":
    main()
