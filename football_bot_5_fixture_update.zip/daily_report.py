
#!/usr/bin/env python3

import sys
import subprocess
import fcntl
import time
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

BASE_DIR = Path(__file__).resolve().parent
PYTHON = sys.executable

REPORT_FILE = BASE_DIR / "latest_report.txt"
LOCK_FILE = BASE_DIR / ".pipeline.lock"

LAGOS = ZoneInfo("Africa/Lagos")
TIMEOUT = 1800


def notify(callback, message):
    """Send progress to the caller without breaking the pipeline."""
    if callback:
        try:
            callback(message)
        except Exception as error:
            print(f"Progress notification error: {error}")


def run_step(title, command, callback=None, number=1, total=4):
    """Run one analysis module and report its progress."""

    notify(
        callback,
        f"FOOTBALL INTELLIGENCE\n\n"
        f"Stage {number}/{total}: {title}\n"
        f"Status: RUNNING\n\n"
        f"Please wait while the system processes the data."
    )

    print(f"\n{'=' * 65}")
    print(f"STARTING: {title}")
    print(f"{'=' * 65}")

    start_time = time.monotonic()

    try:
        result = subprocess.run(
            [PYTHON] + command,
            cwd=BASE_DIR,
            capture_output=True,
            text=True,
            timeout=TIMEOUT,
            check=False,
        )

        elapsed = round(time.monotonic() - start_time, 1)
        output = result.stdout.strip()
        errors = result.stderr.strip()

        if result.returncode == 0:
            status = "SUCCESS"
            icon = "✓"
        else:
            status = f"FAILED (exit code {result.returncode})"
            icon = "✗"

        notify(
            callback,
            f"FOOTBALL INTELLIGENCE\n\n"
            f"{icon} Stage {number}/{total}: {title}\n"
            f"Status: {status}\n"
            f"Time: {elapsed} seconds\n\n"
            f"{'Next module starting...' if number < total else 'Preparing your final report...'}"
        )

        print(f"STATUS: {status}")
        print(f"TIME: {elapsed} seconds")

        if output:
            print(output)

        if errors:
            print("\nDIAGNOSTICS:")
            print(errors)

        return {
            "title": title,
            "status": status,
            "stdout": output,
            "stderr": errors,
            "returncode": result.returncode,
            "elapsed": elapsed,
        }

    except subprocess.TimeoutExpired:
        message = f"Step exceeded {TIMEOUT} seconds."

        notify(
            callback,
            f"✗ Stage {number}/{total}: {title}\n"
            f"Status: TIMEOUT\n\n"
            f"The module took too long to respond."
        )

        return {
            "title": title,
            "status": "TIMEOUT",
            "stdout": "",
            "stderr": message,
            "returncode": -1,
            "elapsed": TIMEOUT,
        }

    except Exception as error:
        notify(
            callback,
            f"✗ Stage {number}/{total}: {title}\n"
            f"Status: ERROR\n\n{str(error)[:500]}"
        )

        return {
            "title": title,
            "status": "ERROR",
            "stdout": "",
            "stderr": str(error),
            "returncode": -1,
            "elapsed": 0,
        }


def shorten(text, limit):
    if not text:
        return "No output was returned."

    if len(text) <= limit:
        return text

    return (
        "[Earlier output omitted]\n\n"
        + text[-limit:]
    )


def build_report(results, started, finished):
    successful = sum(
        1 for item in results
        if item["returncode"] == 0
    )

    failed = len(results) - successful

    lines = [
        "FOOTBALL INTELLIGENCE REPORT",
        "=" * 45,
        "",
        f"Date: {finished.strftime('%d %B %Y')}",
        f"Generated: {finished.strftime('%I:%M:%S %p')} WAT",
        f"Started: {started.strftime('%I:%M:%S %p')} WAT",
        f"Duration: {round((finished - started).total_seconds() / 60, 1)} minutes",
        "",
        "PIPELINE SUMMARY",
        "-" * 45,
        f"Successful modules: {successful}/{len(results)}",
        f"Modules with errors: {failed}",
        "",
        "MODULE RESULTS",
        "-" * 45,
    ]

    for item in results:
        lines.append(
            f"{item['title']}: {item['status']} "
            f"({item['elapsed']} seconds)"
        )

    for item in results:
        lines.extend([
            "",
            "=" * 45,
            item["title"].upper(),
            "=" * 45,
        ])

        if item["stdout"]:
            limit = (
                12000
                if "Prediction" in item["title"]
                else 2500
            )
            lines.append(shorten(item["stdout"], limit))
        else:
            lines.append("No standard output returned.")

        if item["stderr"]:
            lines.extend([
                "",
                "DIAGNOSTICS:",
                shorten(item["stderr"], 2000),
            ])

    lines.extend([
        "",
        "=" * 45,
        "IMPORTANT NOTES",
        "=" * 45,
        "Predictions are statistical assessments, not guarantees.",
        "No bets are placed automatically.",
        "Fewer than five selections may be returned when evidence is insufficient.",
        "The model has not established profitability without proper historical backtesting.",
        "",
        "END OF REPORT",
    ])

    return "\n".join(lines)


def run_pipeline(progress_callback=None):
    """Run the complete analysis only when manually requested."""

    with open(LOCK_FILE, "w", encoding="utf-8") as lock:
        try:
            fcntl.flock(
                lock.fileno(),
                fcntl.LOCK_EX | fcntl.LOCK_NB,
            )
        except BlockingIOError:
            return (
                "Another analysis is already running. "
                "Please wait for it to finish."
            )

        started = datetime.now(LAGOS)

        print("\nFOOTBALL INTELLIGENCE PIPELINE")
        print("Manual execution requested.")

        notify(
            progress_callback,
            "FOOTBALL INTELLIGENCE\n\n"
            "Your analysis request has been accepted.\n"
            "Preparing the four analysis modules..."
        )

        steps = [
            (
                "Fixture Collection",
                ["fixtures.py", "--days", "7", "--max-fixtures", "5"],
            ),
            (
                "Historical Team Analysis",
                [
                    "team_analysis.py", "--collect", "--years", "2",
                    "--fixtures", "--limit", "5",
                    "--batch-file", "selected_fixture_batch.json",
                ],
            ),
            (
                "Team News Analysis",
                [
                    "news_analysis.py", "--collect", "--fixtures",
                    "--limit", "5",
                    "--batch-file", "selected_fixture_batch.json",
                ],
            ),
            (
                "Prediction Engine",
                [
                    "prediction_engine.py", "--days", "7", "--limit", "5",
                    "--batch-file", "selected_fixture_batch.json",
                ],
            ),
        ]

        results = []

        for index, (title, command) in enumerate(steps, start=1):
            result = run_step(
                title,
                command,
                callback=progress_callback,
                number=index,
                total=len(steps),
            )
            results.append(result)

        finished = datetime.now(LAGOS)

        report = build_report(results, started, finished)

        REPORT_FILE.write_text(
            report,
            encoding="utf-8",
        )

        notify(
            progress_callback,
            "FOOTBALL INTELLIGENCE\n\n"
            "✓ All four modules have finished.\n"
            "Your report has been saved.\n\n"
            "Sending the completed report to you now..."
        )

        print(f"\nReport saved to: {REPORT_FILE}")

        return report


if __name__ == "__main__":
    report = run_pipeline()
    print("\n" + report)
